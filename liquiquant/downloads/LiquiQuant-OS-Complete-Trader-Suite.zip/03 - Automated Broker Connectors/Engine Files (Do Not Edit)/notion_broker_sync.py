"""
LiquiQuant OS — Universal Multi-Broker & Webhook Auto-Sync Server
Supports:
  - Direct TradingView Webhook listener (HTTP POST)
  - Auto-importer for FTMO, Topstep, TradeLocker, cTrader CSV exports
  - Direct push to Notion Database API
"""
import os
import json
import csv
import urllib.request
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

NOTION_TOKEN = os.environ.get("NOTION_TOKEN", "secret_YOUR_NOTION_INTEGRATION_TOKEN")
NOTION_DATABASE_ID = os.environ.get("NOTION_DATABASE_ID", "YOUR_NOTION_DATABASE_ID")
PORT = 5055

def send_to_notion(trade: dict):
    if "YOUR_NOTION" in NOTION_TOKEN:
        print(f"[Notion Sync Simulated] Trade: {trade.get('symbol')} {trade.get('direction')} Net PnL: ${trade.get('net_pnl')}")
        return True

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_TOKEN}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }
    body = {
        "parent": {"database_id": NOTION_DATABASE_ID},
        "properties": {
            "Trade Name": {"title": [{"text": {"content": f"{trade.get('source', 'Sync')} - {trade.get('symbol')} ({trade.get('direction')})" }}]},
            "Symbol": {"select": {"name": str(trade.get('symbol', 'EURUSD'))}},
            "Direction": {"select": {"name": str(trade.get('direction', 'LONG'))}},
            "Net PnL ($)": {"number": float(trade.get('net_pnl', 0.0))},
            "Lot Size": {"number": float(trade.get('lot_size', 1.0))},
            "Broker Sync Source": {"select": {"name": trade.get('source', 'Auto-Sync')}}
        }
    }
    try:
        req = urllib.request.Request(url, data=json.dumps(body).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status == 200
    except Exception as e:
        print(f"[Notion API Sync Error] {e}")
        return False

class WebhookHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_len = int(self.headers.get('Content-Length', 0))
        post_body = self.rfile.read(content_len).decode('utf-8')
        try:
            data = json.loads(post_body)
            print(f"[Webhook Received] {data}")
            send_to_notion(data)
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"status":"synced_to_notion"}')
        except Exception as e:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(str(e).encode())

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html')
        self.end_headers()
        self.wfile.write(b'<h1>LiquiQuant OS Notion Broker Bridge Active</h1><p>Send Webhook POST to this endpoint.</p>')

if __name__ == "__main__":
    print(f"Starting LiquiQuant Notion Webhook Server on port {PORT}...")
    server = HTTPServer(('0.0.0.0', PORT), WebhookHandler)
    print(f"Listening on http://localhost:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Server stopped.")
