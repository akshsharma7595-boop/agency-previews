"""
LiquiQuant OS — 1-Click Visual Setup Wizard
Provides a zero-code graphical interface for traders to connect
their Notion Trade Journal and MetaTrader 5 terminal in under 60 seconds.
"""
import os
import re
import json
import webbrowser
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")

def extract_database_id(input_str: str) -> str:
    """Extracts a 32-character Notion database ID from any URL or raw string."""
    clean = input_str.strip()
    if "?" in clean:
        clean = clean.split("?")[0]
    clean_no_dash = clean.replace("-", "")
    match = re.search(r"([a-f0-9]{32})", clean_no_dash, re.IGNORECASE)
    if match:
        return match.group(1).lower()
    return clean

class LiquiQuantWizard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LiquiQuant OS — 1-Click Broker & Notion Setup")
        self.geometry("680x640")
        self.resizable(False, False)
        self.configure(bg="#0B0F17")

        self.discovered_databases = []  # list of (title, id)

        # Load existing config if available
        self.existing_token = ""
        self.existing_db_id = ""
        if os.path.exists(CONFIG_PATH):
            try:
                with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.existing_token = data.get("NOTION_API_KEY", "")
                    if "YOUR_NOTION" in self.existing_token:
                        self.existing_token = ""
                    self.existing_db_id = data.get("NOTION_DATABASE_ID", "")
                    if "YOUR_32" in self.existing_db_id:
                        self.existing_db_id = ""
            except Exception:
                pass

        self.build_ui()

    def build_ui(self):
        # Header banner
        header = tk.Frame(self, bg="#0F172A", padx=24, pady=16)
        header.pack(fill="x")

        title_lbl = tk.Label(
            header,
            text="LIQUIQUANT OS // 1-CLICK DESK SETUP",
            font=("JetBrains Mono", 13, "bold"),
            fg="#2DD4BF",
            bg="#0F172A"
        )
        title_lbl.pack(anchor="w")

        sub_lbl = tk.Label(
            header,
            text="Automated Telemetry: Connect your MetaTrader 5 broker to Notion with zero manual data entry.",
            font=("Segoe UI", 9),
            fg="#94A3B8",
            bg="#0F172A"
        )
        sub_lbl.pack(anchor="w", pady=(3, 0))

        # Main Body
        body = tk.Frame(self, bg="#0B0F17", padx=28, pady=16)
        body.pack(fill="both", expand=True)

        # Step 1: Notion Token
        step1_frame = tk.Frame(body, bg="#0B0F17")
        step1_frame.pack(fill="x", pady=(0, 14))

        s1_head = tk.Frame(step1_frame, bg="#0B0F17")
        s1_head.pack(fill="x")

        s1_num = tk.Label(s1_head, text="STEP 1", font=("JetBrains Mono", 8, "bold"), bg="#10B981", fg="#050811", padx=6, pady=2)
        s1_num.pack(side="left")

        s1_title = tk.Label(s1_head, text=" Paste Your Notion Secret Token", font=("Segoe UI", 10, "bold"), fg="#FFFFFF", bg="#0B0F17")
        s1_title.pack(side="left", padx=(6, 0))

        s1_btn = tk.Button(
            s1_head,
            text="🔗 Open Notion Integrations",
            font=("Segoe UI", 8, "bold"),
            bg="#1E293B",
            fg="#2DD4BF",
            activebackground="#334155",
            activeforeground="#FFFFFF",
            relief="flat",
            cursor="hand2",
            padx=8,
            pady=2,
            command=lambda: webbrowser.open("https://www.notion.so/profile/integrations")
        )
        s1_btn.pack(side="right")

        self.token_entry = tk.Entry(
            step1_frame,
            font=("JetBrains Mono", 9),
            bg="#161E2E",
            fg="#FFFFFF",
            insertbackground="#2DD4BF",
            relief="flat",
            highlightthickness=1,
            highlightcolor="#2DD4BF",
            highlightbackground="#334155"
        )
        self.token_entry.pack(fill="x", pady=(8, 6), ipady=6)
        if self.existing_token:
            self.token_entry.insert(0, self.existing_token)

        s1_subframe = tk.Frame(step1_frame, bg="#0B0F17")
        s1_subframe.pack(fill="x")

        self.scan_btn = tk.Button(
            s1_subframe,
            text="⚡ Auto-Detect Notion Databases",
            font=("Segoe UI", 9, "bold"),
            bg="#1E293B",
            fg="#10B981",
            activebackground="#334155",
            activeforeground="#FFFFFF",
            relief="flat",
            cursor="hand2",
            padx=12,
            pady=4,
            command=self.scan_notion_databases
        )
        self.scan_btn.pack(side="left")

        s1_hint = tk.Label(
            s1_subframe,
            text="Click 'Copy' next to your internal integration secret in Notion",
            font=("Segoe UI", 8),
            fg="#64748B",
            bg="#0B0F17"
        )
        s1_hint.pack(side="left", padx=(10, 0))

        # Step 2: Database Selector / Input
        step2_frame = tk.Frame(body, bg="#0B0F17")
        step2_frame.pack(fill="x", pady=(0, 14))

        s2_head = tk.Frame(step2_frame, bg="#0B0F17")
        s2_head.pack(fill="x")

        s2_num = tk.Label(s2_head, text="STEP 2", font=("JetBrains Mono", 8, "bold"), bg="#E5C07B", fg="#050811", padx=6, pady=2)
        s2_num.pack(side="left")

        s2_title = tk.Label(s2_head, text=" Select Trade Journal Database", font=("Segoe UI", 10, "bold"), fg="#FFFFFF", bg="#0B0F17")
        s2_title.pack(side="left", padx=(6, 0))

        # Combobox for detected databases
        self.db_combo_var = tk.StringVar(value="-- Click 'Auto-Detect Notion Databases' above --")
        self.db_combo = ttk.Combobox(
            step2_frame,
            textvariable=self.db_combo_var,
            state="readonly",
            font=("Segoe UI", 9)
        )
        self.db_combo.pack(fill="x", pady=(8, 4), ipady=4)
        self.db_combo.bind("<<ComboboxSelected>>", self.on_database_selected)

        # Or manual entry fallback
        s2_manual_head = tk.Label(
            step2_frame,
            text="Or paste your Notion page URL directly below:",
            font=("Segoe UI", 8),
            fg="#64748B",
            bg="#0B0F17"
        )
        s2_manual_head.pack(anchor="w", pady=(4, 2))

        self.db_entry = tk.Entry(
            step2_frame,
            font=("JetBrains Mono", 9),
            bg="#161E2E",
            fg="#FFFFFF",
            insertbackground="#2DD4BF",
            relief="flat",
            highlightthickness=1,
            highlightcolor="#2DD4BF",
            highlightbackground="#334155"
        )
        self.db_entry.pack(fill="x", pady=(2, 0), ipady=5)
        if self.existing_db_id:
            self.db_entry.insert(0, self.existing_db_id)

        # Status / Guidance Box
        self.status_box = tk.Label(
            body,
            text="Ready. Enter your Notion token above and click 'Auto-Detect Notion Databases'.",
            font=("Segoe UI", 8),
            fg="#94A3B8",
            bg="#161E2E",
            padx=12,
            pady=8,
            wraplength=600,
            justify="left",
            anchor="w"
        )
        self.status_box.pack(fill="x", pady=(6, 14))

        # Bottom Action Buttons
        btn_frame = tk.Frame(body, bg="#0B0F17")
        btn_frame.pack(fill="x", pady=(4, 0))

        self.test_btn = tk.Button(
            btn_frame,
            text="⚡ Test & Save Connection",
            font=("Segoe UI", 10, "bold"),
            bg="#10B981",
            fg="#050811",
            activebackground="#059669",
            activeforeground="#FFFFFF",
            relief="flat",
            cursor="hand2",
            padx=16,
            pady=10,
            command=self.verify_and_save
        )
        self.test_btn.pack(side="left", fill="x", expand=True, padx=(0, 6))

        self.launch_btn = tk.Button(
            btn_frame,
            text="🚀 Start MT5 Live Sync Bridge",
            font=("Segoe UI", 10, "bold"),
            bg="#1E293B",
            fg="#94A3B8",
            activebackground="#334155",
            activeforeground="#FFFFFF",
            relief="flat",
            cursor="hand2",
            padx=16,
            pady=10,
            command=self.launch_bridge
        )
        self.launch_btn.pack(side="right", fill="x", expand=True, padx=(6, 0))

    def scan_notion_databases(self):
        token = self.token_entry.get().strip()
        if not token or "YOUR_" in token:
            self.status_box.config(
                text="⚠️ Please paste your Notion token first (starts with 'ntn_' or 'secret_').",
                fg="#F87171"
            )
            return

        self.status_box.config(text="🔍 Searching your Notion workspace for databases...", fg="#E5C07B")
        self.update()

        url = "https://api.notion.com/v1/search"
        headers = {
            "Authorization": f"Bearer {token}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json"
        }
        payload = json.dumps({"filter": {"value": "database", "property": "object"}}).encode('utf-8')

        try:
            req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                results = data.get("results", [])

                if not results:
                    self.status_box.config(
                        text="⚠️ Token is valid, but no databases have been shared with this integration yet!\n\n"
                             "👉 In Notion: Open your 'Trading Journal' page -> click '•••' (top-right) -> "
                             "'Connect to' -> select your integration name. Then click 'Auto-Detect' again.",
                        fg="#FCD34D"
                    )
                    return

                self.discovered_databases = []
                combo_values = []
                best_match_idx = 0

                for idx, db in enumerate(results):
                    title_parts = db.get("title", [])
                    title_text = "".join([t.get("plain_text", "") for t in title_parts]) or "Untitled Database"
                    db_id = db.get("id", "").replace("-", "")
                    self.discovered_databases.append((title_text, db_id))
                    combo_values.append(f"{title_text} ({db_id[:8]}...)")
                    if "journal" in title_text.lower() or "trading" in title_text.lower():
                        best_match_idx = idx

                self.db_combo["values"] = combo_values
                self.db_combo.current(best_match_idx)
                selected_title, selected_id = self.discovered_databases[best_match_idx]
                self.db_entry.delete(0, tk.END)
                self.db_entry.insert(0, selected_id)

                self.status_box.config(
                    text=f"✅ Found {len(results)} database(s)! Auto-selected: '{selected_title}'. Ready to test & save.",
                    fg="#10B981"
                )

        except urllib.error.HTTPError as e:
            if e.code == 401:
                self.status_box.config(
                    text="❌ Invalid Token (401 Unauthorized). Please make sure you copied the exact Secret from Notion Developers.",
                    fg="#F87171"
                )
            else:
                self.status_box.config(text=f"❌ Notion API Error: {e.code} {e.reason}", fg="#F87171")
        except Exception as e:
            self.status_box.config(text=f"❌ Connection error: {e}", fg="#F87171")

    def on_database_selected(self, event):
        idx = self.db_combo.current()
        if 0 <= idx < len(self.discovered_databases):
            title, db_id = self.discovered_databases[idx]
            self.db_entry.delete(0, tk.END)
            self.db_entry.insert(0, db_id)

    def verify_and_save(self):
        token = self.token_entry.get().strip()
        raw_db = self.db_entry.get().strip()

        if not token:
            self.status_box.config(text="⚠️ Please enter your Notion API key.", fg="#F87171")
            return

        if "developers/connections" in raw_db:
            self.status_box.config(
                text="⚠️ That's the Developer settings link! In Notion, open your 'Trading Journal' page and copy THAT URL or click 'Auto-Detect' above.",
                fg="#F87171"
            )
            return

        db_id = extract_database_id(raw_db)
        if not db_id or len(db_id) != 32:
            self.status_box.config(text="⚠️ Could not find a valid 32-character Database ID. Please select or paste your journal database.", fg="#F87171")
            return

        self.status_box.config(text="⏳ Verifying connection with Notion & MetaTrader 5...", fg="#E5C07B")
        self.update()

        # 1. Verify Notion API
        db_title = "Notion Trade Journal"
        try:
            req = urllib.request.Request(
                f"https://api.notion.com/v1/databases/{db_id}",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Notion-Version": "2022-06-28"
                }
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                if resp.status == 200:
                    data = json.loads(resp.read().decode())
                    title_objs = data.get("title", [])
                    if title_objs:
                        db_title = "".join([t.get("plain_text", "") for t in title_objs])
        except Exception as e:
            err_msg = str(e)
            if "404" in err_msg:
                self.status_box.config(
                    text="❌ Database not found. Did you click '•••' in Notion -> 'Connect to' -> select your integration?",
                    fg="#F87171"
                )
                return
            elif "401" in err_msg:
                self.status_box.config(text="❌ Invalid Notion API Key. Please check the secret token.", fg="#F87171")
                return
            else:
                self.status_box.config(text=f"❌ Notion connection error: {err_msg}", fg="#F87171")
                return

        # 2. Check MT5 Connection
        mt5_info = "MT5 Ready"
        try:
            import MetaTrader5 as mt5
            if mt5.initialize():
                acc = mt5.account_info()
                if acc:
                    mt5_info = f"MT5 Connected (#{acc.login} • {acc.server})"
                mt5.shutdown()
            else:
                mt5_info = "MT5 Standby (Will connect when launched)"
        except Exception:
            mt5_info = "MT5 Package Ready"

        # 3. Save to config.json
        cfg_data = {
            "NOTION_API_KEY": token,
            "NOTION_DATABASE_ID": db_id,
            "POLL_INTERVAL_SECONDS": 5
        }
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg_data, f, indent=2)

        self.status_box.config(
            text=f"✅ Verified & Saved! Notion: '{db_title}'. {mt5_info}.\nAuto-Bridge is ready to stream closed trades.",
            fg="#10B981"
        )
        self.launch_btn.config(bg="#10B981", fg="#050811")
        messagebox.showinfo(
            "Setup Verified",
            f"Institutional Connection Verified!\n\n• Notion Database: {db_title}\n• Database ID: {db_id}\n• Status: {mt5_info}\n\nClosed trades from MT5 will now automatically stream into your Notion journal."
        )

    def launch_bridge(self):
        bat_file = os.path.join(SCRIPT_DIR, "..", "Start Live MT5 Sync.bat")
        bridge_py = os.path.join(SCRIPT_DIR, "LiquiQuant_MT5_Notion_Bridge.py")
        if os.path.exists(bat_file):
            os.startfile(bat_file)
            self.destroy()
        elif os.path.exists(bridge_py):
            os.system(f'start cmd /k python "{bridge_py}"')
            self.destroy()

if __name__ == "__main__":
    app = LiquiQuantWizard()
    app.mainloop()
