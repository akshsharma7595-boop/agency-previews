"""
LiquiQuant OS — Live MetaTrader 5 (MT5) to Notion Auto-Sync Bridge
Monitors closed deals in your live or demo MT5 terminal and pushes them
directly into your Notion Trade Journal Database via Notion API.
"""
import os
import sys
import time
import json
import urllib.request
import urllib.error
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")
LOCAL_LOG_PATH = os.path.join(SCRIPT_DIR, "live_trades.json")

VALID_PAIRS = {'EURUSD', 'GBPUSD', 'USDJPY', 'XAUUSD', 'AUDUSD', 'USDCAD', 'BTCUSD'}

def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def derive_session(dt: datetime) -> str:
    """Derives institutional killzone session matching Notion options ('Asia', 'London', 'New York')."""
    utc_hour = dt.hour
    if 0 <= utc_hour < 7:
        return "Asia"
    elif 7 <= utc_hour < 13:
        return "London"
    else:
        return "New York"

def push_to_notion(trade_data: dict, token: str, database_id: str) -> bool:
    """Pushes an automatically derived trade record to Notion Trade Journal."""
    if not token or not database_id or "YOUR_" in token or "YOUR_" in database_id:
        print(f"  [Simulated Sync] {trade_data['symbol']} {trade_data['direction']} | Vol: {trade_data['volume']} | PnL: ${trade_data['pnl']:+.2f} | Session: {trade_data['session']}")
        return True

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Notion-Version": "2022-06-28"
    }

    # Match exact Notion Select options
    outcome = "Win" if trade_data['pnl'] > 0 else ("Loss" if trade_data['pnl'] < 0 else "BE")
    direction = "Buy" if "BUY" in trade_data['direction'].upper() or trade_data['direction'] == "LONG" else "Sell"
    pair_name = trade_data['symbol'] if trade_data['symbol'] in VALID_PAIRS else "Other"
    
    # Calculate simple RR Achieved if risk was standard or derive from price
    rr_achieved = round(abs(trade_data['pnl']) / 100.0, 2) if outcome == "Win" else -1.0

    properties = {
        "Trade": {
            "title": [{"text": {"content": f"{trade_data['symbol']} {direction} #{trade_data['ticket']}"}}]
        },
        "Date": {
            "date": {"start": trade_data['close_time'].split('T')[0]}
        },
        "Pair": {
            "select": {"name": pair_name}
        },
        "Direction": {
            "select": {"name": direction}
        },
        "Session": {
            "select": {"name": trade_data['session']}
        },
        "PnL": {
            "number": trade_data['pnl']
        },
        "Outcome": {
            "select": {"name": outcome}
        },
        "RR Achieved": {
            "number": rr_achieved
        },
        "Followed Plan": {
            "checkbox": True
        },
        "Notes": {
            "rich_text": [{
                "text": {
                    "content": f"Auto-synced MT5 ticket #{trade_data['ticket']} | Vol: {trade_data['volume']} lots | Open: {trade_data['open_price']} | Close: {trade_data['close_price']} | Swap: ${trade_data.get('swap', 0):.2f} | Comm: ${trade_data.get('commission', 0):.2f}"
                }
            }]
        }
    }

    payload = {
        "parent": {"database_id": database_id},
        "properties": properties
    }

    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers=headers, method='POST')
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status == 200
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        print(f"  [Notion API Error {e.code}] {error_body}")
        return False
    except Exception as e:
        print(f"  [Notion Error] {e}")
        return False

def save_local_trade(trade_data: dict):
    """Saves live trade to local json mirror for local terminal display."""
    trades = []
    if os.path.exists(LOCAL_LOG_PATH):
        try:
            with open(LOCAL_LOG_PATH, "r", encoding="utf-8") as f:
                trades = json.load(f)
        except Exception:
            trades = []
    trades.insert(0, trade_data)
    trades = trades[:100]
    try:
        with open(LOCAL_LOG_PATH, "w", encoding="utf-8") as f:
            json.dump(trades, f, indent=2)
    except Exception:
        pass

def run_bridge():
    cfg = load_config()
    token = cfg.get("NOTION_API_KEY", "")
    db_id = cfg.get("NOTION_DATABASE_ID", "")
    poll_sec = cfg.get("POLL_INTERVAL_SECONDS", 5)

    print("=" * 70)
    print("  LIQUIQUANT OS // INSTITUTIONAL MT5 TELEMETRY BRIDGE")
    print("=" * 70)
    print(f"  Notion Database ID : {db_id}")
    print(f"  Polling Frequency  : Every {poll_sec} seconds")
    print("-" * 70)

    try:
        import MetaTrader5 as mt5
        if not mt5.initialize():
            print("  [MT5 Error] Unable to initialize MetaTrader 5 terminal.")
            print("  Please make sure your MetaTrader 5 terminal is running and logged in.")
            return

        account = mt5.account_info()
        if account:
            print(f"  [MT5 CONNECTED] Account: #{account.login} | Name: {account.name}")
            print(f"  Server: {account.server} | Balance: ${account.balance:.2f} | Equity: ${account.equity:.2f}")
        else:
            print("  [MT5 Connected] Terminal active.")

        synced_tickets = set()

        if os.path.exists(LOCAL_LOG_PATH):
            try:
                with open(LOCAL_LOG_PATH, "r", encoding="utf-8") as f:
                    old_trades = json.load(f)
                    for t in old_trades:
                        if "ticket" in t:
                            synced_tickets.add(t["ticket"])
            except Exception:
                pass

        print(f"\n  [Active] Monitoring for closed deals... (Press Ctrl+C to stop)\n")

        while True:
            from_time = datetime.now() - timedelta(days=3)
            to_time = datetime.now() + timedelta(days=1)
            deals = mt5.history_deals_get(from_time, to_time)

            if deals:
                for deal in deals:
                    # deal.entry == 1 means DealEntryOut (closed trade or partial close)
                    if deal.entry == 1 and deal.ticket not in synced_tickets:
                        dt = datetime.fromtimestamp(deal.time)
                        session_name = derive_session(dt)
                        direction = "Buy" if deal.type == 1 else "Sell"

                        trade_payload = {
                            "ticket": deal.ticket,
                            "symbol": deal.symbol,
                            "direction": direction,
                            "open_price": deal.price,
                            "close_price": deal.price,
                            "volume": deal.volume,
                            "pnl": round(deal.profit, 2),
                            "close_time": dt.isoformat(),
                            "session": session_name,
                            "commission": round(deal.commission, 2),
                            "swap": round(deal.swap, 2)
                        }

                        print(f"  [NEW CLOSED DEAL DETECTED] Ticket #{deal.ticket}")
                        print(f"    Symbol: {deal.symbol} | Dir: {direction} | Vol: {deal.volume} | PnL: ${deal.profit:+.2f}")
                        print(f"    Session: {session_name} | Closed At: {dt.strftime('%Y-%m-%d %H:%M:%S')}")

                        success = push_to_notion(trade_payload, token, db_id)
                        if success:
                            print(f"    [OK] Ingested into Notion Trade Journal successfully!")
                        else:
                            print(f"    [Local] Recorded locally into live_trades.json")

                        save_local_trade(trade_payload)
                        synced_tickets.add(deal.ticket)

            time.sleep(poll_sec)

    except KeyboardInterrupt:
        print("\n  [Bridge Stopped by User]")
    except Exception as e:
        print(f"\n  [Error] {e}")

if __name__ == "__main__":
    run_bridge()
