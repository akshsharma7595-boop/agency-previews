@echo off
title LiquiQuant OS - 1-Click Setup Wizard
color 0B
cd /d "%~dp0"
if exist "C:\Users\HP\anaconda3\python.exe" (
    "C:\Users\HP\anaconda3\python.exe" "Engine Files (Do Not Edit)\Setup_Wizard.py"
) else (
    python "Engine Files (Do Not Edit)\Setup_Wizard.py"
)
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Python environment error. Ensure Python is installed.
    pause
)
