@echo off
title LiquiQuant OS - MetaTrader 5 Live Sync Bridge
color 0A
cd /d "%~dp0"
if exist "C:\Users\HP\anaconda3\python.exe" (
    "C:\Users\HP\anaconda3\python.exe" "Engine Files (Do Not Edit)\LiquiQuant_MT5_Notion_Bridge.py"
) else (
    python "Engine Files (Do Not Edit)\LiquiQuant_MT5_Notion_Bridge.py"
)
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Please run '1-Click Setup Wizard.bat' first to configure your credentials.
    pause
)
