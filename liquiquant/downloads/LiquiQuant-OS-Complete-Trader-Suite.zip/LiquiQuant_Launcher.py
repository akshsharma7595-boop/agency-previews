"""
LiquiQuant OS — Institutional Desktop Control Center
Master launcher providing 1-click access to:
1. Mode 1: Manual Drag & Drop Web Terminal (app.html)
2. Mode 2: Auto-Detection Bridge (MT5 -> Notion Live Telemetry)
3. Notion Workspace Master Template & Executive Playbooks
"""
import os
import sys
import webbrowser
import subprocess
import tkinter as tk
from tkinter import ttk, messagebox

# Enable High-DPI awareness on Windows
try:
    import ctypes
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SUITE_DIR = os.path.join(BASE_DIR, "LiquiQuant OS - Complete Institutional Suite")
if not os.path.exists(SUITE_DIR):
    SUITE_DIR = BASE_DIR

CONNECTORS_DIR = os.path.join(SUITE_DIR, "03 - Automated Broker Connectors")
ENGINE_DIR = os.path.join(CONNECTORS_DIR, "Engine Files (Do Not Edit)")
if not os.path.exists(ENGINE_DIR):
    ENGINE_DIR = os.path.join(BASE_DIR, "LiquiQuant Notion Workspace", "Broker Connectors")

PDF_PATH = os.path.join(SUITE_DIR, "Client Welcome & Setup Guide.pdf")
NOTION_URL = "https://app.notion.com/p/Trading-Journal-fc4e3a19cab34a89a8de2276ee567df3"

class LiquiQuantLauncher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LiquiQuant OS // Institutional Desk Manager")
        self.geometry("740x580")
        self.minsize(680, 520)
        self.configure(bg="#0B0F17")

        self.mt5_status_text = "Checking MetaTrader 5..."
        self.mt5_color = "#E5C07B"

        self.build_ui()
        self.check_mt5_status()

    def build_ui(self):
        # Header banner
        header = tk.Frame(self, bg="#0F172A", padx=24, pady=16)
        header.pack(fill="x")

        tag_frame = tk.Frame(header, bg="#0F172A")
        tag_frame.pack(fill="x")

        tag = tk.Label(
            tag_frame,
            text="LIQUIQUANT OS // DUAL-MODE INGESTION DESK",
            font=("Segoe UI", 9, "bold"),
            bg="#10B981",
            fg="#050811",
            padx=8,
            pady=2
        )
        tag.pack(side="left")

        title_lbl = tk.Label(
            header,
            text="Institutional Desk Manager",
            font=("Segoe UI", 18, "bold"),
            fg="#FFFFFF",
            bg="#0F172A"
        )
        title_lbl.pack(anchor="w", pady=(6, 2))

        sub_lbl = tk.Label(
            header,
            text="Instant drag & drop performance statements or automated live broker telemetry.",
            font=("Segoe UI", 9),
            fg="#94A3B8",
            bg="#0F172A"
        )
        sub_lbl.pack(anchor="w")

        # Telemetry Status Bar
        status_bar = tk.Frame(self, bg="#161E2E", padx=24, pady=8)
        status_bar.pack(fill="x")

        self.status_lbl = tk.Label(
            status_bar,
            text=f"⚡ MetaTrader 5 Engine: {self.mt5_status_text}",
            font=("Segoe UI", 9, "bold"),
            fg=self.mt5_color,
            bg="#161E2E"
        )
        self.status_lbl.pack(side="left")

        refresh_btn = tk.Button(
            status_bar,
            text="⟳ Refresh",
            font=("Segoe UI", 8),
            bg="#1E293B",
            fg="#2DD4BF",
            relief="flat",
            cursor="hand2",
            padx=8,
            pady=2,
            command=self.check_mt5_status
        )
        refresh_btn.pack(side="right")

        # Main Body - Action Cards
        body = tk.Frame(self, bg="#0B0F17", padx=24, pady=14)
        body.pack(fill="both", expand=True)

        # MODE 1: Manual Drag & Drop (Zero Setup)
        self.create_card(
            body,
            badge="MODE 1 • ZERO SETUP (FASTEST)",
            badge_bg="#0284C7",
            badge_fg="#FFFFFF",
            title="Open Drag & Drop Web Terminal",
            desc="Drag & drop your MT5 HTML report or CSV statement directly into the terminal for instant equity curves, win-rate analytics, and 1-click executive PDF report handover.",
            btn_text="Open Web Terminal 🌐",
            btn_bg="#0284C7",
            btn_fg="#FFFFFF",
            action=self.open_terminal
        )

        # MODE 2: Auto-Detection (MT5 -> Notion Live)
        self.create_card(
            body,
            badge="MODE 2 • 100% AUTOMATED",
            badge_bg="#10B981",
            badge_fg="#050811",
            title="Start Live MT5 Ingestion Bridge",
            desc="Monitors your MetaTrader 5 terminal in real time. Every closed deal is auto-detected and streamed directly into your Notion Trade Journal table.",
            btn_text="Start Live Bridge 🚀",
            btn_bg="#10B981",
            btn_fg="#050811",
            action=self.start_live_bridge
        )

        # NOTION TEMPLATE LINK
        self.create_card(
            body,
            badge="NOTION SUITE",
            badge_bg="#1E293B",
            badge_fg="#2DD4BF",
            title="Open Master Notion Workspace",
            desc="Open official LiquiQuant OS template with live embedded quant hub, gatekeeper, and 1-click duplication into your personal Notion account.",
            btn_text="Duplicate Notion 🔗",
            btn_bg="#1E293B",
            btn_fg="#2DD4BF",
            action=self.open_notion_template
        )

        # Bottom Frame: PDF Manual
        bottom_frame = tk.Frame(body, bg="#0B0F17")
        bottom_frame.pack(fill="x", pady=(8, 0))

        btn_pdf = tk.Button(
            bottom_frame,
            text="📄 View Institutional Playbook & Onboarding Guide (PDF)",
            font=("Segoe UI", 9, "bold"),
            bg="#161E2E",
            fg="#E2E8F0",
            relief="flat",
            cursor="hand2",
            padx=12,
            pady=8,
            command=self.open_pdf
        )
        btn_pdf.pack(fill="x")

    def create_card(self, parent, badge, badge_bg, badge_fg, title, desc, btn_text, btn_bg, btn_fg, action):
        row = tk.Frame(parent, bg="#161E2E", padx=16, pady=10, highlightthickness=1, highlightbackground="#1E293B")
        row.pack(fill="x", pady=(0, 8))

        left = tk.Frame(row, bg="#161E2E")
        left.pack(side="left", fill="both", expand=True)

        top_l = tk.Frame(left, bg="#161E2E")
        top_l.pack(fill="x")

        b_lbl = tk.Label(top_l, text=badge, font=("Segoe UI", 7, "bold"), bg=badge_bg, fg=badge_fg, padx=5, pady=1)
        b_lbl.pack(side="left")

        title_lbl = tk.Label(top_l, text=f" {title}", font=("Segoe UI", 10, "bold"), fg="#FFFFFF", bg="#161E2E")
        title_lbl.pack(side="left")

        desc_lbl = tk.Label(left, text=desc, font=("Segoe UI", 8), fg="#94A3B8", bg="#161E2E", wraplength=460, justify="left")
        desc_lbl.pack(anchor="w", pady=(3, 0))

        btn = tk.Button(
            row,
            text=btn_text,
            font=("Segoe UI", 8, "bold"),
            bg=btn_bg,
            fg=btn_fg,
            relief="flat",
            cursor="hand2",
            padx=14,
            pady=8,
            command=action
        )
        btn.pack(side="right", padx=(10, 0))

    def check_mt5_status(self):
        try:
            import MetaTrader5 as mt5
            if mt5.initialize():
                acc = mt5.account_info()
                if acc:
                    self.mt5_status_text = f"Connected (#{acc.login} • {acc.server} • Equity: ${acc.equity:,.2f})"
                    self.mt5_color = "#10B981"
                else:
                    self.mt5_status_text = "MT5 Running (Account Standby)"
                    self.mt5_color = "#2DD4BF"
                mt5.shutdown()
            else:
                self.mt5_status_text = "MT5 Standby (Will connect when MT5 opens)"
                self.mt5_color = "#E5C07B"
        except Exception:
            self.mt5_status_text = "MT5 Ready"
            self.mt5_color = "#94A3B8"

        self.status_lbl.config(
            text=f"⚡ MetaTrader 5 Engine: {self.mt5_status_text}",
            fg=self.mt5_color
        )

    def open_notion_template(self):
        try:
            os.startfile(NOTION_URL)
        except Exception:
            webbrowser.open(NOTION_URL)

    def open_terminal(self):
        candidates = [
            r"C:\Users\HP\Desktop\Digital products\app.html",
            r"C:\Users\HP\Desktop\Digital products\LiquiQuant OS - Complete Institutional Suite\app.html",
            os.path.join(BASE_DIR, "app.html"),
            os.path.join(BASE_DIR, "..", "app.html"),
            r"C:\Users\HP\Desktop\Digital products\LiquiQuant Website\app.html"
        ]
        target = None
        for c in candidates:
            if os.path.exists(c):
                target = os.path.abspath(c)
                break

        if target:
            try:
                os.startfile(target)
            except Exception:
                try:
                    subprocess.Popen(['cmd.exe', '/c', 'start', '', target])
                except Exception:
                    webbrowser.open(f"file:///{target.replace(os.sep, '/')}")
        else:
            webbrowser.open("https://liquiquant.netlify.app/app.html")

    def start_live_bridge(self):
        bridge_script = os.path.join(ENGINE_DIR, "LiquiQuant_MT5_Notion_Bridge.py")
        if not os.path.exists(bridge_script):
            bridge_script = os.path.join(BASE_DIR, "LiquiQuant Notion Workspace", "Broker Connectors", "LiquiQuant_MT5_Notion_Bridge.py")

        if os.path.exists(bridge_script):
            try:
                subprocess.Popen(
                    ['cmd.exe', '/k', sys.executable, os.path.abspath(bridge_script)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE
                )
            except Exception as e:
                messagebox.showerror("Execution Error", f"Failed to start bridge: {e}")
        else:
            messagebox.showerror("Error", f"Bridge script not found at: {bridge_script}")

    def open_pdf(self):
        if os.path.exists(PDF_PATH):
            os.startfile(os.path.abspath(PDF_PATH))
        else:
            messagebox.showwarning("Notice", "PDF guide is located in folder '02 - Institutional Playbook & Manuals'.")

if __name__ == "__main__":
    app = LiquiQuantLauncher()
    app.mainloop()
