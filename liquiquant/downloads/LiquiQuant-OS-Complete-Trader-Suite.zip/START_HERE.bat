@echo off
title LiquiQuant OS - Desk Control Center
cd /d "%~dp0"
if exist "C:\Users\HP\anaconda3\python.exe" (
    start "" "C:\Users\HP\anaconda3\python.exe" "LiquiQuant_Launcher.py"
) else (
    start "" python "LiquiQuant_Launcher.py"
)
exit
