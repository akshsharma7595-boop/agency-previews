# 🛡️ Module 01: Prop Firm Position Sizing & Drawdown Survival Engine

> **Notion Template Guide & Formulas 2.0**  
> *Color Palette: Dark Obsidian (`#050811`), Electric Emerald (`#10B981`), Liquid Gold (`#F59E0B`)*

---

## ⚡ The Institutional Law of Prop Survival
On a **$100,000 Prop Firm Challenge**, your true usable capital is never $100,000.  
Your actual working balance is the **$10,000 Maximum Trailing Drawdown Limit** and your **$5,000 Daily Drawdown Limit**.

- Risking **2.0% per trade ($2,000)** gives you only **5 losses** before total account termination.
- Risking **0.50% per trade ($500)** gives you a **20-trade consecutive survival buffer**.
- At **3:1 R:R**, 1 winning trade (+$1,500) completely recovers **3 full losses**.

---

## 📊 Notion Database Properties & Formulas 2.0

Import `01_Prop_Firm_Lot_Calculator_Notion.csv` into your Notion workspace or create a new database with the following properties:

| Property Name | Property Type | Description / Notion Formula 2.0 |
| :--- | :--- | :--- |
| **Account Profile** | `Title` | Name of prop challenge (e.g. *FTMO 100K Challenge*) |
| **Starting Capital ($)** | `Number` | Initial account balance (e.g. `100000`) |
| **Current Equity ($)** | `Number` | Live equity balance in your broker (e.g. `98500`) |
| **Daily Drawdown Limit (%)** | `Number` | Daily breach threshold (e.g. `5.0`) |
| **Max Trailing Drawdown (%)** | `Number` | Maximum challenge drawdown (e.g. `10.0`) |
| **Risk Per Trade (%)** | `Number` | Quantitative risk allocation (`0.50` or `1.0`) |
| **Stop Loss (Pips/Pts)** | `Number` | Chart invalidation distance (e.g. `15`) |
| **Asset Class** | `Select` | `Forex`, `Commodities`, `US Indices`, `Crypto` |
| **Symbol** | `Select` | `EURUSD`, `GBPUSD`, `XAUUSD`, `NAS100 / NQ`, `US500 / ES` |
| **Pip/Point Value ($)** | `Number` | Dollar per pip/point on 1.00 standard lot |
| **Max Risk Allowed ($)** | `Formula` | `prop("Starting Capital ($)") * (prop("Risk Per Trade (%)") / 100)` |
| **Distance to Max DD ($)** | `Formula` | `(prop("Starting Capital ($)") * (1 - prop("Max Trailing Drawdown (%)") / 100)) - prop("Current Equity ($)")` |
| **Recommended Lot Size** | `Formula` | `round((prop("Max Risk Allowed ($)") / (prop("Stop Loss (Pips/Pts)") * prop("Pip/Point Value ($)"))) * 100) / 100` |
| **Drawdown Status** | `Formula` | `if(prop("Current Equity ($)") >= prop("Starting Capital ($)"), "🟢 IN PROFIT", if(prop("Distance to Max DD ($)") >= (prop("Starting Capital ($)") * 0.05), "🟢 HEALTHY BUFFER", "🔴 CAUTION: LOW DRAWDOWN BUFFER"))` |

---

## 🎨 Notion Color Gradient Callout Setup

Copy and paste these stylized blocks into your Notion page for the exact LiquiQuant OS aesthetic:

### 🟢 Emerald Callout (Execution Approved):
> **QUANT SIZING APPROVED // 0.50% RISK LOCK**  
> `Status: Optimal` • *Stop loss distance verified against liquidity sweep level. Never exceed recommended lots.*

### 🟡 Gold Callout (Drawdown Advisory):
> **DRAWDOWN ALERT // PROTECT EQUITY BUFFER**  
> `Status: High Caution` • *Current equity is within 3% of Daily Loss Limit. Reduce trade risk to 0.25% until high-timeframe order flow realigns.*

---

## 🔗 Live Broker Data Feed Connection
To auto-populate your **Current Equity ($)** directly from your MT4/MT5 terminal or broker account, see **`05_Broker_Auto_Sync_Hub_TradingView_MT5_cTrader.md`**.
