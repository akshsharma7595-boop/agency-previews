# 🛡️ Prop-Firm Lot Size & Drawdown Survival Engine (Free Notion Edition)

> **The Quantitative Position Sizing & Drawdown Calculator for Notion**  
> *Developed by Aksh Sharma (NISM Certified Equity Derivatives Analyst)*  
> *Support: liquiquant.os@gmail.com | Storefront: https://liquiquant.netlify.app*

---

## 📦 What's Inside This Free Download
1. **`01_Prop_Firm_Lot_Calculator_Notion.csv`**: Ready-to-import Notion database table with multi-asset formulas (Forex, Gold, US Indices, Crypto).
2. **`01_Prop_Firm_Lot_Calculator_Notion.md`**: Step-by-step Notion Formulas 2.0 implementation guide.
3. **`notion_embed_widget.html`**: Interactive live calculator widget designed in site dark obsidian (`#050811`) and emerald/gold gradients that you can embed in Notion with `/embed`.
4. **`Notion Cover Banner - Free Edition.png`**: High-resolution 1500x600 banner to customize your Notion page header.

---

## ⚡ 1-Minute Quick Start

### Step 1: Import into Notion
1. Open [notion.so](https://www.notion.so) and create a new page: **Prop Firm Lot Calculator**.
2. Upload the included `Notion Cover Banner - Free Edition.png` as your page cover.
3. Click **Import** $\rightarrow$ select **CSV** $\rightarrow$ upload `01_Prop_Firm_Lot_Calculator_Notion.csv`.

### Step 2: Live Interactive Widget (Optional)
On your Notion page, type `/embed` and enter:
```
https://liquiquant.netlify.app/notion-embed.html
```
Instantly enjoy the real-time interactive position calculator and 7-point gatekeeper directly inside your Notion workspace!

---

## ⚡ Ready to Level Up to the Complete Quant OS?
Unlock the complete institutional suite:
- **7-Point SMC Pre-Trade Gatekeeper** (Auto-blocks low probability trades)
- **Institutional Trade Journal & Expectancy Engine** (Calculates R-Multiples & edge)
- **Live MT5 / TradingView Broker Auto-Sync Bridge** (Zero manual journaling)
- **6 Detailed SMC Order Flow Case Studies & Annotated Playbook**

👉 **Unlock Full LiquiQuant OS ($49 / ₹2,999):** [liquiquant.netlify.app](https://liquiquant.netlify.app)
